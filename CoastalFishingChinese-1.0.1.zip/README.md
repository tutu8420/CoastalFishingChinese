# Coastal Fishing 简体中文汉化 + 大龙虾补丁

> 先吐槽一句：**作者，你熬了半天夜做出来的龙虾，只有巴掌大。**
> 我们在深海里泡了四十分钟、拉断了两管体力，捞上来一只"大龙虾"，放在船甲板上跟个虾皮似的。
> 所以这个包里，我们把大龙虾改成了**真正的大龙虾**。

这是 [Coastal Fishing](https://thunderstore.io/c/valheim/p/EchoesOfBunglas/CoastalFishing/)（作者 EchoesOfBunglas）的**简体中文汉化补丁**，同时附带三项改善。**不修改原 mod 的任何文件**，作者更新时不会冲突。

**1. 尺寸对比（同一张桌子上）**

![尺寸对比](https://cdn.jsdelivr.net/gh/tutu8420/CoastalFishingChinese@main/images/lobster-size-compare.jpg)

> 左边那堆是**原样**的龙虾，右边那只紫色大螃蟹是放大后的效果。原版里它们本该差不多大。

**2. 改后的大龙虾，站在草地里**

![大龙虾在野外](https://cdn.jsdelivr.net/gh/tutu8420/CoastalFishingChinese@main/images/big-lobster-in-world.jpg)

**3. 挂上物品架（本包修复的功能）**

![挂在物品架上](https://cdn.jsdelivr.net/gh/tutu8420/CoastalFishingChinese@main/images/lobster-on-item-stand.jpg)

> 原版物品架对龙虾一律拒绝，这个包补了挂点、放行了类型检查，现在它真的能挂墙。

**4. 参照物：原版金枪鱼**

![金枪鱼参照](https://cdn.jsdelivr.net/gh/tutu8420/CoastalFishingChinese@main/images/vanilla-tuna-for-scale.jpg)

> 金枪鱼是游戏自带模型，本来按真鱼做的大小。我们的目标就是让大龙虾接近这个体量。


---

## 这个包做了什么

### 1. 简体中文汉化（141 条）

原 mod 完全没有本地化接口，英文字符串硬编码在 dll 里，所以我们用 Harmony 在运行时替换：

- **物品名**：船钩 / 刺网 / 龙虾笼 / 鱼箱 / 清理台 / 钓鱼浮标 / 鲭鱼 / 黑线鳕 / 绿鳕 / 烤鱼 / 煮龙虾 / 煮蟹钳 ……
- **尺寸前缀**：`Small / Medium / Large` → `小 / 中 / 大`（含 `Small haddock` → 小黑线鳕、`Large lobster` → 大龙虾）
- **物品描述**：全部翻译（包括"整条鲭鱼。在清理台上清理。"这类）
- **交互提示**：搬起 / 打开 / 瞄准并扔出第一个浮标 / 没放饵——把饵放到快捷栏后对着它按数字键 / 装备船钩才能把它拉上来 / 渔获已装进鱼箱 ……
- **状态文字**：正在拉龙虾笼 / 正在拉刺网 / 已泡 XX 分钟 / 拉上来是空的，下次多泡一会儿 ……

### 2. 大龙虾真的变大了

原 mod 的龙虾、螃蟹、鱼，三档尺寸共用同一套模型、缩放都是 1 倍，所以"大龙虾"和"小龙虾"在视觉上毫无区别。

我们加了可配置的视觉缩放，默认值：

| 物品 | 默认倍数 |
|---|---|
| 大龙虾 Large lobster | **5.0 ×** |
| 中龙虾 | 2.5 × |
| 小龙虾 | 1.0 ×（不变） |
| 大蟹 / 中蟹 / 小蟹 | 3.0 / 1.5 / 1.0 × |

嫌不够大？改配置文件里的数字，重启游戏即可：

```
BepInEx/config/dsh.coastalfishing.chinese.cfg
```

### 3. 龙虾可以挂在物品架上了

原版物品架要求物品 prefab 里有名为 `attach` 的子节点，而且会按物品类型过滤——mod 的龙虾两项都不满足，所以**怎么点都挂不上**。这个包补上了挂点，也放行了类型检查，现在大龙虾能堂堂正正挂墙上。

---

## 安装

1. 先装好 **Coastal Fishing 2.2.6** 本体（依赖会自动处理）
2. 装这个包
3. 启动游戏，进 `BepInEx\LogOutput.log` 搜 `[CF-CN]`，看到 `Coastal Fishing 汉化补齐已加载` 就成功了

也可参考插件同目录的 `CF-CN.log`（诊断日志，记录打了几个补丁、翻译了几个名字、挂点加在哪些 prefab 上）。

---

## 已知情况

- **清理台在建造菜单的"家具"分类里**，不在"制作"——这是原 mod 写死了 `(PieceCategory)1`，我们没动它，找不到的话去家具分类翻。
- **只汉化原 mod 的文字**。网里顺带捞上来的原版鱼（鲈鱼、金枪鱼等）本来就是中文，不受影响。
- 放大只改**视觉尺寸**，物品的重量、碰撞、手持位置不变，极端倍数下可能出现悬空或轻微穿模。
- **联机**：所有玩家都要装这个包，否则未安装的一方看不到你放大后的龙虾，物品架上也会是空的。
- 不装原 mod 时本包不会生效（硬依赖）。

---

## 卸载

删掉 `BepInEx\plugins\` 下的 `DSH-CoastalFishingChinese` 文件夹即可，不留任何残留。

---

## 反馈与源码

- 源码 / 问题反馈：<https://github.com/tutu8420/CoastalFishingChinese>
- 作者 GitHub：<https://github.com/tutu8420>（汉化、补丁、这个包的源码都在这个账号下）
- Discord：`tutu8420`（加好友可直接问我）

- 汉化词表、放大倍数的默认值、补丁代码都在这个仓库里，欢迎提 Issue 或 PR
- 说明页里的截图也托管在同一个仓库（`images/` 目录），通过 jsDelivr CDN 提供，国内可直接加载
## 致谢

- **EchoesOfBunglas** —— 原 mod 的玩法设计（放网、泡笼、拉绳、分拣）做得很有味道，汉化和放大只是锦上添花
- 以及所有在深海里泡了四十分钟只捞到一只小虾的渔民
